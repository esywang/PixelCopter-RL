try:
    from ple.games.doom import Doom
except:
    print("Couldn't import doom")
from ple.games.catcher import Catcher
from ple.games.flappybird import FlappyBird
from ple.games.monsterkong import MonsterKong
from ple.games.pixelcopter import Pixelcopter
from ple.games.pong import Pong
from ple.games.puckworld import PuckWorld
from ple.games.raycastmaze import RaycastMaze
from ple.games.snake import Snake
from ple.games.waterworld import WaterWorld
